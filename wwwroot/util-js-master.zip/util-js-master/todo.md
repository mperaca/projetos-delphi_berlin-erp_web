﻿# Utilities Task List

## Bugs
- None Known

## Features
- Create function `http.serialize()` and `http.unserialize()` to replace `http.hash()` and `http.param()`
