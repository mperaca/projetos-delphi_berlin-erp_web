
Namespace('com.sandbox', {

	SayHiClass: function() {
		com.sandbox.Console.log('hi');
		return {};
	}

});

Namespace('com.sandbox', {

	testers: function() {
		com.sandbox.Console.log('hi');
		return {};
	}

});

Namespace('com.sandbox', {

	SayHiClass: function() {
		com.sandbox.Console.log('nooooooo');
		return {};
	}

});